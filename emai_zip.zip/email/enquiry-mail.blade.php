<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <div style="border: 1px solid lightgray; border-radius:5px; padding:20px ; margin:0 250px">
        <div>
            <div class="" style="text-align: center; color: #293a5a; ">
                <h2 style="font-size: 25px; margin:0px; ">knc Homedecor</h2>
            </div>
            <div style="text-align: justify;">
                <p>Dear Admin,</p>
                <p>Mr./Mrs. {{ $data['name'] }} has shown interest in product <b>"{{ $data['product_name'] }}"</b> with <b>"{{ $data['product_finishing_value'] }}"</b> finish.</p>
                <p>The contact number of coustomer is <b>{{ $data['number'] }} </b> and email-id is {{ $data['email'] }}.
                   The message from coustomer is as follow:</p>
                <p>"{{ $data['description'] }}"</p>

            </div>
        </div>
    </div>
</body>

</html>